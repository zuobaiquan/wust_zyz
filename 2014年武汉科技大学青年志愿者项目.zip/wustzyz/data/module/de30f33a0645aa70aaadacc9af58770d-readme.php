<p style='line-height:100%'><div style='padding-left:20px;line-height:100%; margin-top:20px;'>
<p>版权所有，【织梦技术研究中心http://www.dedejs.com】保留所有权利。DEDECMS技术在线交流问答QQ群：217479292  欢迎大家加群交流！ </p>
<p>ckplayer视频播放器插件V1.6.1 For DedeCMS 5.7 SP1</p>
<p>插件开发：土匪</p>
<br />
<p style="font-size:18px; color:#F00;"><a href="http://bbs.dedejs.com" target="_blank">如有
问题请加dedecms技术在线交流QQ群：217479292提问或者将问题提交到http://bbs.dedejs.com！</a></p></div></p>