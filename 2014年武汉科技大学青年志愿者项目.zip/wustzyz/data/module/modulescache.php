<?php
global $allmodules;
$GLOBALS['allmodules']['1f35620fb42d452fa2bdc1dee1690f92']='1f35620fb42d452fa2bdc1dee1690f92.xml';
$GLOBALS['allmodules']['59155be87ea60c5c65ec1f7a46a0fc9d']='59155be87ea60c5c65ec1f7a46a0fc9d.xml';
$GLOBALS['allmodules']['b4dbf2eff2125847671e5f2663dbb005']='b4dbf2eff2125847671e5f2663dbb005.xml';
$GLOBALS['allmodules']['de30f33a0645aa70aaadacc9af58770d']='de30f33a0645aa70aaadacc9af58770d.xml';
?>