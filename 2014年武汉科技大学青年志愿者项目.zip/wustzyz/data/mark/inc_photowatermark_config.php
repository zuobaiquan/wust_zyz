<?php
$photo_markup = '0';
$photo_markdown = '0';
$photo_marktype = '2';
$photo_wwidth = '60';
$photo_wheight = '60';
$photo_waterpos = '9';
$photo_watertext = 'http://zyz.wust.edu.cn/';
$photo_fontsize = '20';
$photo_fontcolor = '0,0,0';
$photo_marktrans = '100';
$photo_diaphaneity = '100';
$photo_markimg = 'mark.gif';
?>
