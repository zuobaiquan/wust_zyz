<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'zyz';
$cfg_dbuser = 'root';
$cfg_dbpwd = 'root';
$cfg_dbprefix = 'qnzd_';
$cfg_db_language = 'utf8';


?>